# Informe de Entrega: Módulo ETL Híbrido (Java + Python Polars)

## 1. Resumen de la Solución
Se ha implementado un módulo ETL de alto rendimiento para la integración de datos de órdenes desde dos fuentes Excel hacia PostgreSQL. La solución utiliza un enfoque híbrido:
- **Java**: Actúa como orquestador, invocando el proceso y gestionando el ciclo de vida.
- **Python (Polars/Rust)**: Realiza el procesamiento pesado de datos, lectura paralela de red y carga masiva a base de datos.

---

## 2. Explicación del Motor de Procesamiento (Python)
El script de Python actúa como el motor de carga de alto rendimiento. Su funcionamiento se divide en 4 etapas clave:

### Fase A: Pipeline Paralelo de Lectura (Eficiencia del 100%)
Para minimizar la latencia de la red (`\\192.168.0.3`), el script inicia dos hilos simultáneos:
1.  **Hilo 1 (Primario):** Descarga y procesa la base general de 38,000+ filas.
2.  **Hilo 2 (Secundario - Postventa):** Este hilo lee y mapea el archivo de Postventa de forma independiente.

**La ventaja clave:** Debido a que el archivo secundario es más ligero, el motor Python termina de leerlo, mapearlo y aplicar las reglas de negocio **antes** de que el archivo primario haya terminado de descargarse. Esto significa que cuando el hilo primario finaliza, los datos del secundario ya están procesados y listos en memoria para el merge, eliminando cualquier tiempo de espera adicional. El procesamiento del secundario es, en la práctica, instantáneo para el usuario.

### Fase B: Aplicación de Reglas de Negocio (En Caliente)
Mientras los datos están en memoria (RAM), se transforman instantáneamente:
-   **Lógica de Columna B:** Se autocalcula según el subcentro de costos (`scc`).
-   **Lógica de Columna UEN:** Se asigna "ADN" automáticamente a órdenes <= 17000.
-   **Trazabilidad:** Se marca cada fila con su origen (`BASE_GENERAL` o `POSTVENTA`).

### Fase C: Inteligencia de Merge y Filtrado
Antes de subir a la base de datos, el script realiza una comparación ultra-rápida (usando estructuras de datos tipo *Set* en Rust):
-   Identifica qué órdenes del archivo de Postventa **no existen todavía** en la Base General.
-   Solo anexa los registros nuevos, evitando duplicar información en el ERP.

### Fase D: Carga Masiva Vectorizada (ADBC)
En lugar de insertar fila por fila (método lento tradicional), el script usa el motor **ADBC (Arrow Database Connectivity)**. Esto envía bloques completos de datos de la RAM a PostgreSQL en formato columnar, lo que reduce el tiempo de subida a menos de 2 segundos.

---

## 3. Estudio de Tiempos (Muestreo de 10 Ciclos)
Se realizaron 10 pruebas consecutivas en el ambiente de producción para validar la estabilidad y el rendimiento.

| Muestreo | Tiempo Python (Lógica) | Tiempo Java (Total) | Estado |
| :--- | :--- | :--- | :--- |
| #1 | 3.55s | 5.04s | ✅ |
| #2 | 3.36s | 5.39s | ✅ |
| #3 | 3.51s | 5.14s | ✅ |
| #4 | 3.40s | 5.43s | ✅ |
| #5 | 3.61s | 5.13s | ✅ |
| #6 | 4.44s | 5.92s | ✅ |
| #7 | 4.58s | 6.72s | ✅ |
| #8 | 5.15s | 7.41s | ✅ |
| #9 | 3.67s | 5.66s | ✅ |
| #10 | 3.50s | 5.49s | ✅ |
| **PROMEDIO** | **3.88s** | **5.73s** | **ÉXITO** |

**Conclusión del Estudio:**
La solución original en Java puro tardaba **31.5 segundos**. La nueva solución híbrida tiene un promedio de **5.73 segundos**, logrando una **mejora del 82% en el tiempo de procesamiento**.

---

## 4. Reglas de Negocio Aplicadas (Merge)
Para los registros provenientes exclusivamente de la fuente **Postventa**:
1. **Columna B**: Si `scc` = 20 entonces "31"; si `scc` = 10 entonces "30"; de lo contrario NULL.
2. **Columna UEN**: Si `orden` <= 17000 entonces "ADN"; de lo contrario NULL.
3. **Filtro de Duplicados**: Solo se anexan órdenes que NO existan en el archivo primario.
4. **Trazabilidad**: Se agregó la columna `fuente` para identificar el origen del dato.

