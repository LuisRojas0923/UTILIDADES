# Guía de Despliegue para el Desarrollador de Java

Esta guía explica cómo integrar el módulo ETL de alto rendimiento en el servidor del ERP.

## 1. Requisitos Previos
- Java 8 o superior.
- Conexión de red a `192.168.0.3` (Archivos Excel).
- Acceso a PostgreSQL en `192.168.0.21:5432`.

## 2. Preparación del Entorno (Un solo clic)
Para que no tenga que instalar librerías manualmente, siga estos pasos:
1. Abra una terminal en la carpeta `/python`.
2. Ejecute el script: `./instalar_entorno.ps1`.
   - *Este script instalará automáticamente 'uv' (si no está), creará un entorno virtual aislado (.venv) e instalará todas las dependencias necesarias.*

## 3. Configuración del Orquestador Java
1. En el archivo `PythonRunner.java`, ajuste las rutas en las variables constantes al inicio de la clase:
   ```java
   private static final String BASE_DIR = "C:\\RUTA\\DONDE\\COPIE\\LA_ENTREGA";
   ```
2. Compile la clase e intégrela en el flujo de su aplicación.

## 4. Estructura de la Base de Datos
Asegúrese de que la tabla `basegeneralcostos` tenga la siguiente estructura en PostgreSQL:
- **31 columnas** en total.
- Tipos de datos sugeridos: `TEXT` para la mayoría, `DOUBLE PRECISION` para campos monetarios.
- Columna extra: `fuente` (TEXT).

## 5. Soporte y Mantenimiento
- El script de Python está optimizado con **hilos paralelos** para reducir la latencia de red.
- Si necesita cambiar credenciales de la base de datos, edite la variable `DB_URI` en `upload_buffer_polars.py`.

