import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;

/**
 * PythonRunner - Orquestador Java para el proceso ETL de alto rendimiento.
 * Esta clase ejecuta un script Python optimizado en Polars/Rust.
 */
public class PythonRunner {

    // CONFIGURACIÓN DE RUTAS
    // 1. Ruta sugerida para el servidor de produccion
    private static final String PROD_BASE_DIR = "C:\\ERP\\ETL_ANEXO";
    
    // 2. Ruta de ejecucion actual (para pruebas locales sin configurar nada)
    private static final String LOCAL_BASE_DIR = System.getProperty("user.dir");

    public static void main(String[] args) {
        System.out.println("======================================================================");
        System.out.println("--- ERP: Invocando Modulo ETL (Integracion Java-Python) ---");
        System.out.println("======================================================================\n");
        
        long startTime = System.currentTimeMillis();
        
        int exitCode = runETLProcess();
        
        long elapsed = System.currentTimeMillis() - startTime;
        
        System.out.println("\n======================================================================");
        System.out.println(String.format("Tiempo Total (Orquestacion Java): %.2f segundos", elapsed / 1000.0));
        System.out.println("Codigo de Salida: " + exitCode + (exitCode == 0 ? " (EXITO)" : " (ERROR)"));
        System.out.println("======================================================================");
        
        System.exit(exitCode);
    }

    private static String getFinalBasePath() {
        // Si existe la carpeta de produccion, usarla
        if (new File(PROD_BASE_DIR).exists()) {
            return PROD_BASE_DIR;
        }
        // De lo contrario, usar la ruta donde se esta ejecutando el programa
        return LOCAL_BASE_DIR;
    }

    private static int runETLProcess() {
        try {
            String basePath = getFinalBasePath();
            
            // Construir rutas finales
            String pythonCmd = basePath + "\\python\\.venv\\Scripts\\python.exe";
            String pythonScript = basePath + "\\python\\upload_buffer_polars.py";

            File pythonExe = new File(pythonCmd);
            File scriptFile = new File(pythonScript);

            System.out.println("[INFO] Buscando entorno en: " + basePath);

            if (!pythonExe.exists()) {
                System.err.println("ERROR: No se encuentra el entorno virtual en: " + pythonCmd);
                System.err.println("Asegurese de copiar la carpeta 'python' en: " + basePath);
                System.err.println("Y ejecutar 'instalar_entorno.ps1' dentro de ella.");
                return 1;
            }

            if (!scriptFile.exists()) {
                System.err.println("ERROR: No se encuentra el script Python en: " + pythonScript);
                return 1;
            }

            ProcessBuilder pb = new ProcessBuilder(pythonCmd, pythonScript);
            pb.redirectErrorStream(true); // Combinar stdout y stderr
            
            Process process = pb.start();
            
            // Leer salida en tiempo real
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println("[PY] " + line);
                }
            }
            
            return process.waitFor();
            
        } catch (Exception e) {
            System.err.println("ERROR CRITICO en la orquestacion: " + e.getMessage());
            e.printStackTrace();
            return 1;
        }
    }
}
